from distutils.core import setup

setup(
    name="h_planeFight",
    version="1.0.1",
    description="飞机大战测试",
    author='hyx',
    author_email="675868749@qq.com",
    py_modules=["planeFight","setup"],
)